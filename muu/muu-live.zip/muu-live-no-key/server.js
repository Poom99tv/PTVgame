// ฉากไลฟ์สายมู — ตัวเชื่อม TikTok LIVE กับฉาก
// รับคอมเมนต์ ของขวัญ การกดติดตาม และไลก์ จากไลฟ์ แล้วส่งต่อให้หน้าเว็บฉากแบบเรียลไทม์
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as TLC from 'tiktok-live-connector';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const readConfig = () => JSON.parse(fs.readFileSync(path.join(DIR, 'config.json'), 'utf8'));
let config = readConfig();
const PORT = Number(config.port) || 8787;

// ---------- ส่งอีเวนต์ไปหน้าเว็บ (Server-Sent Events) ----------
const clients = new Set();
let status = { type: 'status', text: 'กำลังเริ่มโปรแกรม…', connected: false };

function broadcast(ev) {
  const line = `data: ${JSON.stringify(ev)}\n\n`;
  for (const res of clients) res.write(line);
}
function setStatus(text, connected) {
  status = { type: 'status', text, connected };
  console.log(`[สถานะ] ${text}`);
  broadcast(status);
}
setInterval(() => { for (const res of clients) res.write(': ping\n\n'); }, 15000);

// ---------- เว็บเซิร์ฟเวอร์ ----------
const HEAD = '<!doctype html><html lang="th"><head><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>';

// ให้หน้าเว็บ https://ptvgame.com/muu/ (หรือเว็บอื่น) อ่านข้อมูลจากโปรแกรมในคอมนี้ได้
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Allow-Private-Network': 'true'
};
let userOverride = ''; // ชื่อช่องที่หน้าเว็บส่งมา (ใช้แทน config.json)

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  for (const [k, v] of Object.entries(CORS)) res.setHeader(k, v);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  if (url.pathname === '/set-user') {
    const u = String(url.searchParams.get('user') || '').trim().replace(/^@/, '');
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    if (!u || /[^\w.]/.test(u)) { res.end(JSON.stringify({ ok: false })); return; }
    const changed = u !== currentUser();
    userOverride = u;
    res.end(JSON.stringify({ ok: true, user: u, changed }));
    if (changed) { clearTimeout(retryTimer); connect(); }
    return;
  }

  if (url.pathname === '/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive'
    });
    res.write('retry: 2000\n\n');
    res.write(`data: ${JSON.stringify(status)}\n\n`);
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }

  if (url.pathname === '/config.json') {
    try { config = readConfig(); } catch (e) { /* ใช้ค่าเดิมถ้าไฟล์เขียนผิด */ }
    const { scene, title, subtitle, tiers, maxPeople, voice } = config;
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify({ app: 'muu-live', scene, title, subtitle, tiers, maxPeople, voice, user: currentUser(), connected: status.connected }));
    return;
  }

  if (url.pathname === '/' || url.pathname === '/index.html') {
    const html = fs.readFileSync(path.join(DIR, 'index.html'), 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(html.trimStart().toLowerCase().startsWith('<!doctype') ? html : HEAD + html + '</body></html>');
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('ไม่พบหน้านี้');
});

// ---------- อ่านข้อมูลจากอีเวนต์ (รองรับรูปแบบข้อมูลทั้งเวอร์ชันเก่าและใหม่ของไลบรารี) ----------
function userOf(d) {
  const u = d.user || d;
  const name = String(u.nickname || u.uniqueId || u.displayId || 'ผู้ชม').slice(0, 30);
  return { id: String(u.uniqueId || u.displayId || u.userId || u.idStr || u.id || name), name };
}
function giftOf(d) {
  const g = d.giftDetails || d.gift || {};
  const ex = d.extendedGiftInfo || {};
  const raw = g.giftName || g.name || d.giftName || ex.name || 'ของขวัญ';
  const coins = Number(g.diamondCount ?? d.diamondCount ?? ex.diamond_count ?? 1) || 1;
  const type = Number(g.giftType ?? g.type ?? d.giftType ?? ex.type ?? 0);
  const count = Number(d.repeatCount || 1) || 1;
  const ended = d.repeatEnd === undefined ? true : Boolean(Number(d.repeatEnd));
  const name = (config.giftNames && config.giftNames[raw]) || raw;
  const forced = config.giftTier && config.giftTier[raw];
  const total = coins * count;
  const tiers = config.tiers || { mid: 10, big: 100 };
  const tier = forced || (total >= tiers.big ? 'big' : total >= tiers.mid ? 'mid' : 'small');
  return { name, coins, count, tier, streaking: type === 1 && !ended };
}

// ---------- เชื่อมต่อไลฟ์ ----------
const Conn = TLC.TikTokLiveConnection || TLC.WebcastPushConnection;
const E = TLC.WebcastEvent || {};
const C = TLC.ControlEvent || {};
let conn = null;
let retryTimer = null;

function scheduleRetry(sec) {
  clearTimeout(retryTimer);
  retryTimer = setTimeout(connect, sec * 1000);
}

function currentUser() {
  return String(userOverride || config.tiktokUsername || '').trim().replace(/^@/, '');
}

async function connect() {
  try { config = readConfig(); } catch (e) {}
  const username = currentUser();
  if (!username || /[^\w.]/.test(username)) {
    setStatus('ยังไม่ได้ใส่ชื่อช่อง ใส่ในหน้าเว็บ หรือใน config.json (ใส่แค่ชื่อหลัง @ เช่น mychannel)', false);
    return;
  }
  if (conn) { try { conn.disconnect(); } catch (e) {} conn = null; }
  if (eulerWs) { try { eulerWs.onclose = null; eulerWs.close(); } catch (e) {} eulerWs = null; }

  // มีคีย์: ใช้ Euler WebSocket; ไม่มีคีย์: ลอง connector โดยไม่ส่ง signApiKey
  // โหมดไม่ใส่คีย์ยังขึ้นกับสิทธิ์และข้อจำกัดของ signing provider
  const key = String(config.signApiKey || config.eulerApiKey || '').trim();
  if (key) return eulerConnect(username, key);

  // รายการของขวัญแบบเสริมเรียก HTTP signing ที่ต้องใช้ Business plan
  // ข้อมูลชื่อ/มูลค่าของขวัญยังอ่านได้จาก payload ของอีเวนต์ตามที่ TikTok ส่งมา
  const options = { enableExtendedGiftInfo: false, processInitialData: false };
  if (config.signApiKey) options.signApiKey = config.signApiKey;
  const c = new Conn(username, options);
  conn = c;

  c.on(E.CHAT || 'chat', (d) => broadcast({ type: 'chat', user: userOf(d), comment: String(d.comment ?? d.content ?? '').slice(0, 80) }));

  c.on(E.GIFT || 'gift', (d) => {
    const gift = giftOf(d);
    if (gift.streaking) return; // ส่งรัวยังไม่จบ รอยอดสุดท้าย
    broadcast({ type: 'gift', user: userOf(d), gift });
  });

  c.on(E.LIKE || 'like', (d) => broadcast({ type: 'like', user: userOf(d), count: Number(d.likeCount || 1) }));

  if (E.FOLLOW || !E.SOCIAL) {
    c.on(E.FOLLOW || 'follow', (d) => broadcast({ type: 'follow', user: userOf(d) }));
  } else {
    c.on(E.SOCIAL, (d) => {
      if (/follow/i.test(String(d.displayType || d.label || ''))) broadcast({ type: 'follow', user: userOf(d) });
    });
  }

  c.on(E.STREAM_END || 'streamEnd', () => {
    setStatus('ไลฟ์จบแล้ว จะรอเชื่อมต่อใหม่เมื่อเริ่มไลฟ์', false);
    scheduleRetry(20);
  });
  c.on(C.DISCONNECTED || 'disconnected', () => {
    if (conn !== c) return;
    setStatus('หลุดจากไลฟ์ กำลังเชื่อมต่อใหม่…', false);
    scheduleRetry(8);
  });
  c.on(C.ERROR || 'error', (err) => console.log('[ข้อผิดพลาด]', err?.exception?.message || err?.message || err?.info || err));

  try {
    setStatus(`กำลังลองเชื่อมต่อ @${username} โดยไม่ใส่ API key…`, false);
    await c.connect();
    setStatus(`เชื่อมต่อไลฟ์ @${username} แล้ว`, true);
  } catch (err) {
    console.log('[ข้อผิดพลาด]', err && err.message ? err.message : err);
    setStatus(`ยังเชื่อมต่อ @${username} ไม่ได้: ตรวจว่าช่องกำลังไลฟ์ และดูข้อผิดพลาดในหน้าต่างโปรแกรม (บริการอาจจำกัดโหมดไม่ใส่คีย์) จะลองใหม่ใน 60 วินาที`, false);
    scheduleRetry(60);
  }
}


// ---------- เชื่อมต่อผ่าน Euler Stream WebSocket (ฟรี แพ็กเกจ Community) ----------
let eulerWs = null;
async function getWS() {
  if (globalThis.WebSocket) return globalThis.WebSocket;
  const m = await import('ws');
  return m.WebSocket || m.default;
}
function isFollowMsg(d) {
  const dt = d.common && d.common.displayText ? JSON.stringify(d.common.displayText) : '';
  return Number(d.action) === 1 || /follow/i.test(`${dt} ${d.displayType || ''} ${d.label || ''}`);
}
async function eulerConnect(username, key) {
  const WS = await getWS();
  const qsx = new URLSearchParams({ uniqueId: username, apiKey: key, 'features.bundleEvents': 'true' });
  setStatus(`กำลังเชื่อมต่อไลฟ์ @${username}…`, false);
  let live = false;
  const ws = new WS((process.env.EULER_WS_URL || 'wss://ws.eulerstream.com') + '?' + qsx.toString());
  eulerWs = ws;
  const markLive = () => { if (!live) { live = true; setStatus(`เชื่อมต่อไลฟ์ @${username} แล้ว`, true); } };
  const handle = (m) => {
    if (!m || typeof m !== 'object') return;
    const t = m.type, d = m.data || {};
    if (t === 'roomInfo' || t === 'tiktok.connect') return markLive();
    if (t === 'WebcastChatMessage') { markLive(); if (d.comment) broadcast({ type: 'chat', user: userOf(d), comment: String(d.comment).slice(0, 80) }); }
    else if (t === 'WebcastGiftMessage') { markLive(); const gift = giftOf(d); if (!gift.streaking) broadcast({ type: 'gift', user: userOf(d), gift }); }
    else if (t === 'WebcastLikeMessage') { markLive(); broadcast({ type: 'like', user: userOf(d), count: Number(d.likeCount || 1) }); }
    else if (t === 'WebcastSocialMessage') { markLive(); if (isFollowMsg(d)) broadcast({ type: 'follow', user: userOf(d) }); }
  };
  ws.onmessage = (e) => {
    const raw = typeof e.data === 'string' ? e.data : (Buffer.isBuffer(e.data) ? e.data.toString('utf8') : null);
    if (!raw) return;
    let d; try { d = JSON.parse(raw); } catch (x) { return; }
    const list = Array.isArray(d) ? d : Array.isArray(d.messages) ? d.messages : [d];
    for (const m of list) { try { handle(m); } catch (x) { console.log('[ข้อผิดพลาด]', x.message); } }
  };
  ws.onerror = () => {};
  ws.onclose = (e) => {
    if (eulerWs !== ws) return;
    eulerWs = null;
    const c = e.code;
    if (c === 4400 || c === 4401 || c === 4403) { setStatus('คีย์ Euler Stream ใน config.json ไม่ถูกต้อง แก้แล้วปิดเปิดโปรแกรมใหม่', false); return; }
    if (c === 4404) { setStatus(`@${username} ยังไม่ได้เริ่มไลฟ์ จะลองใหม่ทุก 30 วินาที`, false); return scheduleRetry(30); }
    if (c === 4429) { setStatus('เชื่อมต่อถี่เกินไป รอ 1 นาทีแล้วลองใหม่', false); return scheduleRetry(60); }
    if (c === 4005) { setStatus('ไลฟ์จบแล้ว จะรอเชื่อมต่อใหม่เมื่อเริ่มไลฟ์', false); return scheduleRetry(30); }
    setStatus(`หลุดจากไลฟ์ (รหัส ${c}) กำลังเชื่อมต่อใหม่…`, false);
    scheduleRetry(8);
  };
}

// ---------- เริ่มทำงาน ----------
function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
  }
  return out;
}

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') console.log(`\nพอร์ต ${PORT} ถูกใช้อยู่ อาจเปิดโปรแกรมนี้ซ้ำไว้แล้ว ปิดหน้าต่างเก่าก่อน หรือเปลี่ยน port ใน config.json`);
  else console.log(err);
  process.exit(1);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('==============================================');
  console.log('  ฉากไลฟ์สายมู พร้อมใช้งาน');
  console.log('==============================================');
  console.log('  ทำลิงก์สำหรับ TikTok LIVE Studio ที่:  https://ptvgame.com/muu/');
  console.log('    (เลือก "คอม + LIVE Studio" ใส่ชื่อช่อง แล้วกดคัดลอกลิงก์ ไม่ต้องใช้คีย์)');
  console.log(`  ลิงก์ในคอม (ถ้า LIVE Studio รับ):  http://127.0.0.1:${PORT}/?live`);
  console.log(`  เลือกฉากผ่านลิงก์:            ?live&scene=loykrathong | shrine | ganesha | wessuwan | guanyin | maenak`);
  console.log(`  ทดสอบบนคอม (มีปุ่มจำลอง):   http://localhost:${PORT}/?live&test`);
  for (const ip of lanAddresses()) console.log(`  เปิดบนมือถือ (Wi-Fi เดียวกัน): http://${ip}:${PORT}/?live`);
  console.log('  ปิดหน้าต่างนี้เมื่อเลิกไลฟ์');
  console.log('==============================================\n');
  connect();
});
