#!/data/data/com.termux/files/usr/bin/bash
# ฉากไลฟ์สายมู — เปิดโปรแกรมบนมือถือ Android ผ่านแอป Termux (ฟรี)
# วิธีเรียก: bash start-android.sh

SRC="$(cd "$(dirname "$0")" && pwd)"
APP="$HOME/muu-live"

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "กำลังติดตั้ง Node.js (ครั้งแรกครั้งเดียว)..."
  pkg update -y && pkg install -y nodejs-lts
fi

# พื้นที่เก็บไฟล์ทั่วไปของ Android (Download) ติดตั้งส่วนประกอบไม่ได้ จึงคัดลอกโปรแกรมเข้าไปในพื้นที่ของ Termux
if [ "$SRC" != "$APP" ]; then
  mkdir -p "$APP"
  for f in index.html server.js package.json README.txt start-android.sh; do cp -f "$SRC/$f" "$APP/" 2>/dev/null; done
  # config.json: คัดลอกทับทุกครั้ง เพื่อให้แก้ไฟล์ในโฟลเดอร์ Download ได้
  cp -f "$SRC/config.json" "$APP/"
fi
cd "$APP" || exit 1

if [ ! -d node_modules ]; then
  echo ""
  echo "เปิดครั้งแรก กำลังติดตั้งส่วนประกอบ รอสักครู่..."
  npm install --omit=dev
fi

# กันมือถือหยุดโปรแกรมตอนสลับไปแอป TikTok
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock

echo ""
echo "เปิด Chrome บนมือถือเครื่องนี้ แล้วไปที่  http://localhost:8787/?live"
node server.js
