@echo off
chcp 65001 >nul
title ฉากไลฟ์ลอยกระทง
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo ยังไม่ได้ติดตั้ง Node.js
  echo กำลังเปิดหน้าดาวน์โหลด ให้เลือกเวอร์ชัน LTS ติดตั้งให้เสร็จ แล้วดับเบิลคลิกไฟล์นี้อีกครั้ง
  start https://nodejs.org/
  pause
  exit /b
)

if not exist node_modules (
  echo.
  echo เปิดครั้งแรก กำลังติดตั้งส่วนประกอบ รอสักครู่...
  call npm install --omit=dev
)

node server.js
pause
