@echo off
chcp 65001 >nul
rem เปิดฉากเป็นหน้าต่างแยก (ไม่มีแถบเบราว์เซอร์) ไว้ให้ TikTok LIVE Studio จับหน้าต่าง
rem ต้องเปิด start-windows.bat ไว้ก่อน
rem เปลี่ยนฉากได้ที่บรรทัด set SCENE=  (loykrathong, shrine, ganesha, wessuwan, guanyin, maenak)

set SCENE=loykrathong

start "" msedge --app="http://127.0.0.1:8787/?live&scene=%SCENE%" --window-size=540,990 --user-data-dir="%TEMP%\muu-live-window" --autoplay-policy=no-user-gesture-required
