#!/bin/bash
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "ยังไม่ได้ติดตั้ง Node.js"
  echo "กำลังเปิดหน้าดาวน์โหลด ให้เลือกเวอร์ชัน LTS ติดตั้งให้เสร็จ แล้วดับเบิลคลิกไฟล์นี้อีกครั้ง"
  open "https://nodejs.org/"
  read -p "กด Enter เพื่อปิดหน้าต่าง"
  exit 1
fi

if [ ! -d node_modules ]; then
  echo ""
  echo "เปิดครั้งแรก กำลังติดตั้งส่วนประกอบ รอสักครู่..."
  npm install --omit=dev
fi

node server.js
